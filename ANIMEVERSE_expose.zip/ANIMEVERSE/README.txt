# ANIMEVERSE — Exposé interactif

## Contenu
- `index.html` : structure des slides / sections.
- `style.css` : design responsive.
- `script.js` : navigation de partage, sondage local et génération de QR code.

## Tester
Ouvre `index.html` dans un navigateur. Une connexion internet est nécessaire pour Google Fonts, la bibliothèque QR et les liens externes.

## Mettre en ligne gratuitement
1. Crée un compte sur Netlify (https://www.netlify.com/) ou GitHub Pages.
2. Dépose le dossier `anime_expose` sur Netlify (Add new site > Deploy manually), ou publie les trois fichiers dans un dépôt GitHub puis active Pages.
3. Copie l'adresse publique HTTPS obtenue.
4. Ouvre ton site, descends à « Partage l'expérience », colle l'adresse publique et clique « Créer le QR ».
5. Télécharge le QR code et partage-le.

## Important — sondage
Cette version stocke les votes dans le navigateur de chaque participant (localStorage). Les résultats ne sont donc PAS centralisés entre les visiteurs. Pour un vrai vote commun, connecte le formulaire à Google Forms, Firebase ou Supabase. Ne présente pas les résultats locaux comme le résultat général de la classe.

## Affiches des films
Les blocs de films sont des visuels graphiques originaux inspirés des ambiances des films, et non leurs affiches officielles. Pour intégrer les affiches officielles, remplace les éléments `.poster` dans `index.html` par des balises `<img>` avec des fichiers dont tu as les droits ou une autorisation d'utilisation.

## Droits
Les noms, œuvres et musiques appartiennent à leurs ayants droit. Les liens musicaux ouvrent des recherches YouTube plutôt que d'héberger les pistes audio.
